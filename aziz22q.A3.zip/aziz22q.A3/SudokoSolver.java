import java.awt.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class SudokoSolver {
	
	//CSP
	// Variables = all the unsolved cells
	// Domain = 1 to 9
	// Constraints, no repeats in the same column, row, or block

	// number of rows and columns
	private final static int ROWS = 9;
	private final static int COLS = 9;
	
	static Cell[][] grid;
	
	static Stack<Cell> stack = new Stack<Cell>();// stack used in dfs
	static Stack<Cell> unassignedStack = new Stack<Cell>(); // stack to keep track of unassigned cells
	static ArrayList<Cell> unassignedList = new ArrayList<Cell>();
	
	File file;
	
	static int nodeCount = 0;
	//program time
	static long pStartTime;	
	static long pEndTime;
	//search time
	static long sStartTime;	
	static long sEndTime;
 
	public static void main(String[] args) {
		//pStartTime = new Date().getTime();
		pStartTime = System.nanoTime();
		
		File f = new File(args[0]);
		try {
			SudokoSolver ss = new SudokoSolver(f);
			System.out.println(" Original Grid: \n");
			ss.printGrid();
			//ss.printGrid();
			//ss.printGrid();
			//ss.simplebacktracking();
			//ss.printGrid();
			//ss.sbt_dfs();
			//ss.printGrid();			
			//System.out.println(conflict(grid[0][8], 2));
			
			if(args.length>=3){
				if((args[1].equals("MRV") && args[2].equals("FC")) || (args[1].equals("FC") && args[2].equals("MRV"))){
					sStartTime = System.nanoTime();
					ss.bts_fc();
					sEndTime = System.nanoTime();
					//ss.bts_mrv();
					
					System.out.println(" Grid after BTS FC: \n");
					ss.printGrid();
					System.out.println(" Nodes: " + nodeCount);
					//pEndTime = new Date().getTime();
					pEndTime = System.nanoTime();
					
					long pDifference = pEndTime - pStartTime;				 
					//System.out.println(" Total time in milliseconds: " + pDifference);
					System.out.println(" Total time in nanoseconds: " + pDifference);
					
					long sDifference = sEndTime - sStartTime;				 
					//System.out.println(" Search time in milliseconds: " + sDifference);
					System.out.println(" Search time in nanoseconds: " + sDifference);
				}
			}
			else
			{
				//sStartTime = new Date().getTime();
				sStartTime = System.nanoTime();
				ss.simplebacktracking();
				//sEndTime = new Date().getTime();
				sEndTime = System.nanoTime();
				
				System.out.println(" Grid after SBT: \n");
				ss.printGrid();
				System.out.println(" Nodes: " + nodeCount);
				//pEndTime = new Date().getTime();
				pEndTime = System.nanoTime();
				
				long pDifference = pEndTime - pStartTime;				 
				//System.out.println(" Total time in milliseconds: " + pDifference);
				System.out.println(" Total time in nanoseconds: " + pDifference);
				
				long sDifference = sEndTime - sStartTime;				 
				//System.out.println(" Search time in milliseconds: " + sDifference);
				System.out.println(" Search time in nanoseconds: " + sDifference);
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	

	public SudokoSolver(File file) throws FileNotFoundException {
		
		grid = new Cell[ROWS][COLS];
		populateGrid(file);

	}
	

	//update the domain of a cell
	public void domainUpdate(Cell cell)
	{
		for (int i = 1; i <= 9; i++) {	
			if(cell.domain.contains(i) && conflict(cell, i))
			{
				int index = cell.domain.indexOf(i);
				if (index != -1) {
					cell.domain.remove(index);
				}
			}
		}
		
		//System.out.println(cell.row + ", " + cell.col);
		//for(int i =0; i<cell.domain.size();i++)
		//{
			//System.out.println(cell.domain.get(i));
		//}
		
	}
	
	public void bts_fc(){
		
		stack.add(grid[0][0]);	
		
		findUnassignedCells();
		
		if(!unassignedStack.isEmpty()){
			bts_fc(unassignedStack.pop());
		}
		
	}
	
	public boolean bts_fc(Cell cell) {

		
		if (isSolved()) {
			//System.out.println("Solved!");
			return true;
		}
		
		for (int i = 0; i < cell.domain.size(); i++) {
			
			nodeCount++;
			int value = cell.domain.get(i);
			
			if(!conflict(cell, value))
			{
				grid[cell.row][cell.col].value = value;
				nodeCount++;
				
				if(unassignedStack.isEmpty())
				{					
					return true;
				}
				
				unassignedList.remove(cell);
				
				ArrayList<Cell> domainRemovedList = new ArrayList<Cell>();
				
				for (Cell c : unassignedList) {
					if(c.domain.contains(value) && conflict(c, value))
					{
						int index = c.domain.indexOf(value);
						c.domain.remove(index);
						domainRemovedList.add(c);
						Cell successor = unassignedStack.pop();	
						
						if(c.domain.size()==0)
						{
							grid[cell.row][cell.col].value = 0;
							unassignedStack.add(successor);
							unassignedList.add(cell);
							for(Cell r : domainRemovedList ){
								r.domain.add(value);
							}
							nodeCount++;
							
						}
						
						if (bts_fc(successor)){
							return true;
						}
					}
				}
				
//				Cell successor = unassignedStack.pop();	
				//System.out.println("cell: " + cell.row + ", " +cell.col);
				//System.out.println("successor: " + successor.row + ", " + successor.col );
				
//				if (bts_fc(successor)){
//					return true;
//				}
			//	System.out.println(cell.row + ", " +cell.col);
			//	System.out.println(i);
//				grid[cell.row][cell.col].value = 0;
//				unassignedStack.add(successor);
//				unassignedList.add(cell);
//				nodeCount++;

			}

		}

		return false;
	}

	// populates with -1 or 99
	public void populateGrid(File file) throws FileNotFoundException {
		this.file = file;
		BufferedReader br = new BufferedReader(new FileReader(file));
		Scanner charScanner = new Scanner(br);

		// populate the grid with sudoku values from the file
		for (int i = 0; i < ROWS; i++) {
			for (int j = 0; j < COLS; j++) {
				if (charScanner.hasNext()) {
					String s = charScanner.next();
					grid[i][j] = new Cell(i, j);
					// System.out.println(s);
					grid[i][j].setValue(Integer.parseInt(s));
				}
			}
		}

	}

	// prints the grid (debug code)
	public void printGrid() {
		// testing the grid
		String output = "";
		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLS; col++) {
				output += " " + grid[row][col].value;
			}
			output += "\n";
		}
		System.out.println(output);
	}

	public void simplebacktracking() {
		stack.add(grid[0][0]);	
		findUnassignedCells();
		if(!unassignedStack.isEmpty()){
			sbt(unassignedStack.pop());
		}
	}

	public boolean sbt(Cell cell) {

						
		if (isSolved()) {
			//System.out.println("Solved!");
			return true;
		}
		
		for (int i = 1; i <= 9; i++) {
			nodeCount++;
			
			if(!conflict(cell, i))
			{
				grid[cell.row][cell.col].value = i;
				nodeCount++;
				
				if(unassignedStack.isEmpty())
				{					
					return true;
				}
				Cell successor = unassignedStack.pop();	
				//System.out.println("cell: " + cell.row + ", " +cell.col);
				//System.out.println("successor: " + successor.row + ", " + successor.col );
				
				if (sbt(successor)){
					return true;
				}
			//	System.out.println(cell.row + ", " +cell.col);
			//	System.out.println(i);
				grid[cell.row][cell.col].value = 0;
				unassignedStack.add(successor);
				nodeCount++;

			}

		}

		return false;
	}

	public void findUnassignedCells(){
		
		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLS; col++) {
				nodeCount++;
				if (grid[row][col].value == 0) {
					unassignedStack.add(grid[row][col]);
					domainUpdate(grid[row][col]);
					unassignedList.add(grid[row][col]);
					//System.out.println(grid[row][col].row + " " + grid[row][col].col);
				}
			}

		}
		
	}
	
	public boolean conflict(Cell cell, int value) {

		// check column for constraints
		for (int i = 0; i < 9; i++) {
			if (grid[cell.row][i].getValue() == value) {
				return true;
			}
		}

		// check row for constraints
		for (int i = 0; i < 9; i++) {
			if (grid[i][cell.col].getValue() == value) {
				return true;
			}
		}

		// check block for constraints
		// 0-2, 0-2 | 0-2, 3-5 | 0-2, 6-8
		// 3-5, 0-2 | 3-5, 3-5 | 3-5, 6-8
		// 6-8, 0-2 | 6-8, 3-5 | 6-8, 6-8
		int rs, re, cs, ce;
		rs = re = cs = ce = 0;
		
		//if the cell is in block 1,1
		if(cell.row <= 2 && cell.col <= 2) {
			rs = 0; re = 2; cs = 0;	ce = 2; }		
		//if the cell is in block 1,2
		if(cell.row <= 2 && cell.col >= 3 && cell.col <= 5) {
			rs = 0; re = 2; cs = 3;	ce = 5; }		
		//if the cell is in block 1,3
		if(cell.row <= 2 && cell.col >=6  && cell.col <= 8) {
			rs = 0; re = 2; cs = 6;	ce = 8; }
		
		//if the cell is in block 2,1
		if(cell.row >= 3 && cell.row <= 5 && cell.col <= 2) {
			rs = 3; re = 5; cs = 0;	ce = 2; }		
		//if the cell is in block 2,2
		if(cell.row >= 3 && cell.row <= 5 && cell.col >= 3 && cell.col <= 5) {
			rs = 3; re = 5; cs = 3;	ce = 5; }		
		//if the cell is in block 2,3
		if(cell.row >= 3 && cell.row <= 5 && cell.col >=6  && cell.col <= 8) {
			rs = 3; re = 5; cs = 6;	ce = 8; }
		
		//if the cell is in block 3,1
		if(cell.row >= 6 && cell.row <= 8 && cell.col <= 2) {
			rs = 6; re = 8; cs = 0;	ce = 2; }		
		//if the cell is in block 2,2
		if(cell.row >= 6 && cell.row <= 8 && cell.col >= 3 && cell.col <= 5) {
			rs = 6; re = 8; cs = 3;	ce = 5; }		
		//if the cell is in block 2,3
		if(cell.row >= 3 && cell.row <= 5 && cell.col >=6  && cell.col <= 8) {
			rs = 6; re = 8; cs = 6;	ce = 8; }
	
		if(blockConflict(cell, value, rs, re, cs, ce))
		{
			return true;
		}
		
		return false;
	}
	
	public boolean blockConflict(Cell cell, int value, int rs, int re, int cs, int ce)
	{

			for (int i = rs; i <= re; i++) {
				for (int j = cs; j <= ce; j++) {
					if(grid[i][j].value == value) {
						return true;
					}
				}
			}

		return false;
	}
	
	public boolean isSolved() {

		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLS; col++) {
				if (grid[row][col].value == 0) {
					return false;
				}
			}

		}

		return true;
	}

	// depth first search that finds the unassigned cells
	public static void sbt_dfs() {

		Cell cell = stack.pop();
		cell.color = "grey";
		
		
		//if it is unassigned 
		if (cell.getValue() == 0) {
			
		}

		Cell top, bottom, left, right;

		if (cell.row - 1 >= 0) {
			top = grid[cell.row - 1][cell.col];
			if (!top.color.equals("grey") && !top.color.equals("black")) {
				top.color = "grey";
				stack.push(top);
				sbt_dfs();
			}
		}
		if (cell.row + 1 < ROWS) {
			bottom = grid[cell.row + 1][cell.col];

			if (!bottom.color.equals("grey") && !bottom.color.equals("black")) {
				bottom.color = "grey";
				stack.push(bottom);
				sbt_dfs();
			}
		}
		if (cell.col + 1 < COLS) {
			right = grid[cell.row][cell.col + 1];

			if (!right.color.equals("grey") && !right.color.equals("black")) {
				right.color = "grey";
				stack.push(right);
				sbt_dfs();
			}
		}
		if (cell.col - 1 > 0) {

			left = grid[cell.row][cell.col - 1];

			if (!left.color.equals("grey") && !left.color.equals("black")) {
				left.color = "grey";
				stack.push(left);
				sbt_dfs();
			}
		}

		cell.color = "black";

	}
	
	public void solveCell(Cell cell) {

		// check column for constraints
		for (int i = 0; i < 9; i++) {
			if (grid[cell.row][i].getValue() != 0) {
				// System.out.println(grid[cell.row][i].getValue());
				int index = cell.domain.indexOf(grid[cell.row][i].value);
				if (index != -1) {
					cell.domain.remove(index);
				}
			}
		}

		// check row for constraints
		for (int i = 0; i < 9; i++) {
			if (grid[i][cell.col].getValue() != 0) {
				// System.out.println(grid[i][cell.col].getValue());
				int index = cell.domain.indexOf(grid[i][cell.col].value);
				if (index != -1) {
					cell.domain.remove(index);
				}
			}
		}

		// check block for constraints
		// 0-2, 0-2 | 0-2, 3-5 | 0-2, 7-8
		// 3-5, 0-2 | 3-5, 3-5 | 3-5, 7-8
		// 7-8, 0-2 | 7-8, 3-5 | 7-8, 7-8

		for (int i = 0; i < 9; i++) {
			if (grid[i][cell.col].getValue() != 0) {
				// System.out.println(grid[i][cell.col].getValue());
				int index = cell.domain.indexOf(grid[i][cell.col].value);
				if (index != -1) {
					cell.domain.remove(index);
				}
			}
		}

		if (!cell.domain.isEmpty()) {
			grid[cell.row][cell.col].setValue(cell.domain.get(0));
		} else {
			grid[cell.row][cell.col].setValue(-1);
		}
	}


}
