import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class SudokoSolver {

	// CSP
	// Variables = all the unsolved cells
	// Domain = 1 to 9
	// Constraints, no repeats in the same column, row, or block

	// number of rows and columns
	private final static int ROWS = 9;
	private final static int COLS = 9;

	private Cell[][] grid;

	// stack to keep track of unassigned cells
	private Stack<Cell> unassignedStack = new Stack<Cell>();
	// list of unassigned for domain check
	private ArrayList<Cell> unassignedList = new ArrayList<Cell>();
	private ArrayList<Cell> assignedList = new ArrayList<Cell>();

	File file;

	private int nodeCount = 0;
	// program time
	static long pStartTime;
	static long pEndTime;
	// search time
	static long sStartTime;
	static long sEndTime;

	//the main method reads the arguments and calls the appropriate search algorithm
	public static void main(String[] args) {
		//program start time
		pStartTime = System.nanoTime();

		File f = new File(args[0]);
		try {
			SudokoSolver ss = new SudokoSolver(f);
			System.out.println("Original Grid: \n");
			ss.printGrid();
			//for FC 
			if (args.length == 2 && args[1].equals("FC")) {

				sStartTime = System.nanoTime();
				ss.bts_fc();
				sEndTime = System.nanoTime();


				System.out.println("Grid after BTS FC: \n");
				ss.printGrid();
				System.out.println(" Nodes: " + ss.nodeCount);
				pEndTime = System.nanoTime();

				long pDifference = pEndTime - pStartTime;
				System.out
						.println(" Total time in nanoseconds: " + pDifference);
				long sDifference = sEndTime - sStartTime;
				System.out.println(" Search time in nanoseconds: "
						+ sDifference);

			}
			//for FC MRV
			else if (args.length >= 3) {
				if ((args[1].equals("MRV") && args[2].equals("FC"))
						|| (args[1].equals("FC") && args[2].equals("MRV"))) {
					sStartTime = System.nanoTime();
					ss.bts_fc_mrv();
					sEndTime = System.nanoTime();

					System.out.println("Grid after BTS FC MRV: \n");
					ss.printGrid();
					System.out.println(" Nodes: " + ss.nodeCount);
					pEndTime = System.nanoTime();

					long pDifference = pEndTime - pStartTime;
					System.out.println(" Total time in nanoseconds: "
							+ pDifference);

					long sDifference = sEndTime - sStartTime;
					System.out.println(" Search time in nanoseconds: "
							+ sDifference);
				}
			// for standard backtracking
			} else {

				sStartTime = System.nanoTime();
				ss.simplebacktracking();
				sEndTime = System.nanoTime();

				System.out.println("Grid after SBT: \n");
				ss.printGrid();
				System.out.println(" Nodes: " + ss.nodeCount);
				pEndTime = System.nanoTime();

				long pDifference = pEndTime - pStartTime;
				System.out
						.println(" Total time in nanoseconds: " + pDifference);

				long sDifference = sEndTime - sStartTime;
				System.out.println(" Search time in nanoseconds: "
						+ sDifference);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	//constructor
	public SudokoSolver(File file) throws FileNotFoundException {

		grid = new Cell[ROWS][COLS];
		populateGrid(file);

	}

	// update the domain of a cell
	public void domainUpdate(Cell cell) {
		for (int i = 1; i <= 9; i++) {
			if (cell.domain.contains(i) && conflict(cell, i)) {
				int index = cell.domain.indexOf(i);
				if (index != -1) {
					cell.domain.remove(index);
				}
			}
		}
	}

	// backtracking with forward checking
	public void bts_fc() {

		findUnassignedCells();

		if (!unassignedStack.isEmpty()) {
			bts_fc(unassignedStack.pop());
		}

	}
	
	// backtracking with forward checking
	public boolean bts_fc(Cell cell) {

		//if a solution is found
		if (isSolved()) {
			return true;
		}

		unassignedList.remove(cell);
		assignedList.add(cell);
		for (int i : cell.domain) {
			nodeCount++;
			int value = i;
			grid[cell.row][cell.col].value = value;

			if (unassignedStack.isEmpty()) {
				return true;
			}

			// to keep track of the unassigned cell whose domain will be updated
			ArrayList<Cell> domainRemovedList = new ArrayList<Cell>();
			boolean failed = false;

			for (Cell c : unassignedList) {
				if (!assignedList.contains(c) && c.domain.contains(value)
						&& fc_connected(cell, c)
						&& (c.row != cell.row && c.col != cell.col)) {
					int index = c.domain.indexOf(value);
					c.domain.remove(index);
					domainRemovedList.add(c);
				}
			}

			forLoop: for (Cell c : unassignedList) {
				if (c.domain.size() == 0) {
					nodeCount++;
					for (Cell r : domainRemovedList) {
						r.domain.add(value);
					}
					failed = true;
					break forLoop;
				}
			}

			if (!failed) {

				Cell successor = unassignedStack.pop();
				if (bts_fc(successor)) {
					return true;
				}

				return false;
			}
		}

		return false;
	}

	// backtracking with forward checking and MRV
	public void bts_fc_mrv() {

		findUnassignedCells();

		if (!unassignedStack.isEmpty()) {
			Cell cell = unassignedList.get(0);
			for (Cell c : unassignedList) {
				if (c.domain.size() < cell.domain.size()) {
					cell = c;
				}
			}

			bts_fc_mrv(cell);
		}

	}
	
	// backtracking with forward checking and MRV
	public boolean bts_fc_mrv(Cell cell) {

		if (isSolved()) {
			return true;
		}

		unassignedList.remove(cell);
		assignedList.add(cell);
		for (int i : cell.domain) {

			nodeCount++;
			int value = i;

			grid[cell.row][cell.col].value = value;

			if (unassignedStack.isEmpty()) {
				return true;
			}

			// to keep track of the unassigned cell whose domain will be updated
			ArrayList<Cell> domainRemovedList = new ArrayList<Cell>();
			boolean failed = false;

			for (Cell c : unassignedList) {
				if (!assignedList.contains(c) && c.domain.contains(value)
						&& fc_connected(cell, c)
						&& (c.row != cell.row && c.col != cell.col)) {
					int index = c.domain.indexOf(value);
					c.domain.remove(index);
					domainRemovedList.add(c);
				}
			}

			forLoop: for (Cell c : unassignedList) {
				if (c.domain.size() == 0) {
					nodeCount++;
					for (Cell r : domainRemovedList) {
						r.domain.add(value);
					}
					failed = true;
					break forLoop;
				}
			}

			if (!failed) {

				if (unassignedList.isEmpty()) {
					return true;
				}

				Cell successor = unassignedList.get(0);

				for (Cell c : unassignedList) {
					if (c.domain.size() < successor.domain.size()) {
						successor = c;
					}
				}

				if (bts_fc_mrv(successor)) {
					return true;
				}

				return false;
			}
		}

		return false;
	}

	public boolean fc_connected(Cell cell1, Cell cell2) {

		if (cell1.row == cell2.row || cell1.col == cell2.col) {
			return true;
		}

		// check block for constraints
		// 0-2, 0-2 | 0-2, 3-5 | 0-2, 6-8
		// 3-5, 0-2 | 3-5, 3-5 | 3-5, 6-8
		// 6-8, 0-2 | 6-8, 3-5 | 6-8, 6-8
		int rs, re, cs, ce;
		rs = re = cs = ce = 0;

		// if the cell is in block 1,1
		if (cell1.row <= 2 && cell1.col <= 2) {
			rs = 0;
			re = 2;
			cs = 0;
			ce = 2;
		}
		// if the cell is in block 1,2
		if (cell1.row <= 2 && cell1.col >= 3 && cell1.col <= 5) {
			rs = 0;
			re = 2;
			cs = 3;
			ce = 5;
		}
		// if the cell is in block 1,3
		if (cell1.row <= 2 && cell1.col >= 6 && cell1.col <= 8) {
			rs = 0;
			re = 2;
			cs = 6;
			ce = 8;
		}

		// if the cell is in block 2,1
		if (cell1.row >= 3 && cell1.row <= 5 && cell1.col <= 2) {
			rs = 3;
			re = 5;
			cs = 0;
			ce = 2;
		}
		// if the cell is in block 2,2
		if (cell1.row >= 3 && cell1.row <= 5 && cell1.col >= 3
				&& cell1.col <= 5) {
			rs = 3;
			re = 5;
			cs = 3;
			ce = 5;
		}
		// if the cell is in block 2,3
		if (cell1.row >= 3 && cell1.row <= 5 && cell1.col >= 6
				&& cell1.col <= 8) {
			rs = 3;
			re = 5;
			cs = 6;
			ce = 8;
		}

		// if the cell is in block 3,1
		if (cell1.row >= 6 && cell1.row <= 8 && cell1.col <= 2) {
			rs = 6;
			re = 8;
			cs = 0;
			ce = 2;
		}
		// if the cell is in block 2,2
		if (cell1.row >= 6 && cell1.row <= 8 && cell1.col >= 3
				&& cell1.col <= 5) {
			rs = 6;
			re = 8;
			cs = 3;
			ce = 5;
		}
		// if the cell is in block 2,3
		if (cell1.row >= 6 && cell1.row <= 8 && cell1.col >= 6
				&& cell1.col <= 8) {
			rs = 6;
			re = 8;
			cs = 6;
			ce = 8;
		}

		if (cell2.row >= rs && cell2.row <= re && cell2.col >= cs
				&& cell2.col <= ce) {
			return true;
		}

		return false;
	}

	// populate the grid with sudoku values from the file
	public void populateGrid(File file) throws FileNotFoundException {
		this.file = file;
		BufferedReader br = new BufferedReader(new FileReader(file));
		Scanner charScanner = new Scanner(br);

		// populate the grid with sudoku values from the file
		for (int i = 0; i < ROWS; i++) {
			for (int j = 0; j < COLS; j++) {
				if (charScanner.hasNext()) {
					String s = charScanner.next();
					grid[i][j] = new Cell(i, j);
					grid[i][j].setValue(Integer.parseInt(s));
				}
			}
		}

	}

	// prints the grid (debug code)
	public void printGrid() {

		String output = "";
		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLS; col++) {
				output += grid[row][col].value + " ";
			}
			output += "\n";
		}
		System.out.println(output);
	}
	//simple backtracking
	public void simplebacktracking() {
		findUnassignedCells();
		if (!unassignedStack.isEmpty()) {
			sbt(unassignedStack.pop());
		}
	}
	//simple backtracking
	public boolean sbt(Cell cell) {

		if (isSolved()) {
			return true;
		}

		for (int i = 1; i <= 9; i++) {

			nodeCount++;

			if (!conflict(cell, i)) {
				grid[cell.row][cell.col].value = i;

				if (unassignedStack.isEmpty()) {
					return true;
				}

				Cell successor = unassignedStack.pop();

				// if there is a solution for this assignment
				if (sbt(successor)) {
					return true;
				}

				// otherwise backtrack
				grid[cell.row][cell.col].value = 0;
				unassignedStack.add(successor);
				nodeCount++;

			}

		}

		return false;
	}
	// find all cells with zeroes as value
	public void findUnassignedCells() {

		Stack<Cell> tmp = new Stack<Cell>();
		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLS; col++) {

				if (grid[row][col].value == 0) {

					tmp.add(grid[row][col]);
					domainUpdate(grid[row][col]);
					unassignedList.add(grid[row][col]);
				}
			}

		}

		unassignedStack.clear();

		while (!tmp.isEmpty()) {
			unassignedStack.add(tmp.pop());
		}

	}
	
	//find if there will be a conflict if a value is assigned to a particular cell
	public boolean conflict(Cell cell, int value) {

		// check column for constraints
		for (int i = 0; i < 9; i++) {
			if (grid[cell.row][i].getValue() == value) {
				return true;
			}
		}

		// check row for constraints
		for (int i = 0; i < 9; i++) {
			if (grid[i][cell.col].getValue() == value) {
				return true;
			}
		}

		// find to which block the cell belongs
		// 0-2, 0-2 | 0-2, 3-5 | 0-2, 6-8
		// 3-5, 0-2 | 3-5, 3-5 | 3-5, 6-8
		// 6-8, 0-2 | 6-8, 3-5 | 6-8, 6-8
		int rs, re, cs, ce;
		rs = re = cs = ce = 0;

		// if the cell is in block 1,1
		if (cell.row <= 2 && cell.col <= 2) {
			rs = 0;
			re = 2;
			cs = 0;
			ce = 2;
		}
		// if the cell is in block 1,2
		if (cell.row <= 2 && cell.col >= 3 && cell.col <= 5) {
			rs = 0;
			re = 2;
			cs = 3;
			ce = 5;
		}
		// if the cell is in block 1,3
		if (cell.row <= 2 && cell.col >= 6 && cell.col <= 8) {
			rs = 0;
			re = 2;
			cs = 6;
			ce = 8;
		}

		// if the cell is in block 2,1
		if (cell.row >= 3 && cell.row <= 5 && cell.col <= 2) {
			rs = 3;
			re = 5;
			cs = 0;
			ce = 2;
		}
		// if the cell is in block 2,2
		if (cell.row >= 3 && cell.row <= 5 && cell.col >= 3 && cell.col <= 5) {
			rs = 3;
			re = 5;
			cs = 3;
			ce = 5;
		}
		// if the cell is in block 2,3
		if (cell.row >= 3 && cell.row <= 5 && cell.col >= 6 && cell.col <= 8) {
			rs = 3;
			re = 5;
			cs = 6;
			ce = 8;
		}

		// if the cell is in block 3,1
		if (cell.row >= 6 && cell.row <= 8 && cell.col <= 2) {
			rs = 6;
			re = 8;
			cs = 0;
			ce = 2;
		}
		// if the cell is in block 2,2
		if (cell.row >= 6 && cell.row <= 8 && cell.col >= 3 && cell.col <= 5) {
			rs = 6;
			re = 8;
			cs = 3;
			ce = 5;
		}
		// if the cell is in block 2,3
		if (cell.row >= 6 && cell.row <= 8 && cell.col >= 6 && cell.col <= 8) {
			rs = 6;
			re = 8;
			cs = 6;
			ce = 8;
		}

		if (blockConflict(cell, value, rs, re, cs, ce)) {
			return true;
		}

		return false;
	}
	//check if there will be a block conflict
	public boolean blockConflict(Cell cell, int value, int rs, int re, int cs,
			int ce) {

		for (int i = rs; i <= re; i++) {
			for (int j = cs; j <= ce; j++) {
				if (grid[i][j].value == value) {
					return true;
				}
			}
		}

		return false;
	}

	//returns true if all the cells have values other than zero
	public boolean isSolved() {

		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLS; col++) {
				if (grid[row][col].value == 0) {
					return false;
				}
			}

		}

		return true;
	}

}
