import java.util.ArrayList;
import java.util.List;
/*
 * The cell class for each search node
 * */

public class Cell {

	int value;
	int row;
	int col;
	List<Integer> domain;
	String color;

	public Cell(int row, int col) {
		this.row = row;
		this.col = col;
		this.value = 0;
		this.color = "white";
		this.domain = new ArrayList<Integer>();
		for (int i = 1; i < 10; i++) {
			this.domain.add(i);
		}
	}

	public void setValue(int value) {
		this.value = value;
	}

	public int getValue() {
		return this.value;
	}

	public String getColor() {
		return this.color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public List<Integer> getDomain() {
		return this.domain;
	}

	public void setDomain(List<Integer> domain) {
		this.domain = domain;
	}
}
